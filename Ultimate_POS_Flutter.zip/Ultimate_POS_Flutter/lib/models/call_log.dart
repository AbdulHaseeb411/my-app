// import 'package:call_log/call_log.dart';
import 'package:intl/intl.dart';

class CallLogModel {
  // createLog(CallLogEntry callLog) {
  //   DateTime startDate = DateTime.fromMillisecondsSinceEpoch(callLog.timestamp!)
  //       .subtract(Duration(seconds: callLog.duration!));
  //   DateTime endDate = DateTime.fromMillisecondsSinceEpoch(callLog.timestamp!);
  //   Map logDetail = {
  //     'mobile_number': '${callLog.number}',
  //     'mobile_name': '${callLog.name}',
  //     'call_type': '${callLog.callType}',
  //     'start_time': '${DateFormat("yyyy-MM-dd HH:mm:ss").format(startDate)}',
  //     'end_time': '${DateFormat("yyyy-MM-dd HH:mm:ss").format(endDate)}',
  //     'duration': '${callLog.duration}',
  //   };
  //   print(logDetail);
  //   return logDetail;
  // }
}
